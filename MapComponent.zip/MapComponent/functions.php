<?php
 
namespace Flynt\Components\MapComponent ;
 
use Flynt\FieldVariables ;
use Flynt\Utils\Options ;
 
add_filter ( 'Flynt/addComponentData?name=MapComponent' , function ( $data ) {
return $data ;
} ) ;
 
function getACFLayout ( )
{
return [
'name' => 'MapComponent' ,
'label' => __ ( 'Block: Map Component' , 'flynt' ) ,
'sub_fields' => [
[
'label' => __ ( 'General' , 'flynt' ) ,
'name' => 'generalTab' ,
'type' => 'tab' ,
'placement' => 'top' ,
'endpoint' => 0 ,
] ,
[
'label' => __ ( 'Content' , 'flynt' ) ,
'name' => 'contentHtml' ,
'type' => 'wysiwyg' ,
'delay' => 1 ,
'media_upload' => 0 ,
'required' => 1 ,
] ,
]
] ;
}
 
Options :: addTranslatable ( 'MapComponent' , [
 
] ) ;
 
Options :: addGlobal ( 'MapComponent' , [
 
] ) ;